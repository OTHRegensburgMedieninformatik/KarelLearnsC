#include "structs.h"

extern World world;
extern Cursor cursor;
extern Input input;
//extern SDL_Surface *worldImages[MAX_TILES];
