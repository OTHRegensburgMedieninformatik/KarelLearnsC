#include "structs.h"

extern SDL_Surface *screen;
extern World world;
TTF_Font *font, *speedFont;
