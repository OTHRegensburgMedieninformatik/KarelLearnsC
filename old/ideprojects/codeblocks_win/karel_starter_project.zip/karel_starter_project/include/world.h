#include "structs.h"

extern World world;
extern WorldInformation worldInformation;
extern SDL_Surface *wallVerticalImage, *wallHorizontalImage, *beeperImage;
void drawWorld(void);
